# encoding: UTF-8
module Irrgarten
    module Directions
        LEFT = :left
        RIGHT = :right
        UP = :up
        DOWN = :down
    end
end
